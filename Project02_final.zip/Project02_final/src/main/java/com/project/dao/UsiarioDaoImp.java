package com.project.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.project.model.Usuario;

import de.mkammerer.argon2.Argon2;
import de.mkammerer.argon2.Argon2Factory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class UsiarioDaoImp implements UsuarioDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Usuario> getUsuarios() {
		
		String query= "from Usuario";
		
		//hay dos maneras de escribirlo
		//1era Manera:
		//List<Usuario> resultado=entityManager.createQuery(query).getResultList();
		//return resultado;
		
		//2da Manera:
		return entityManager.createQuery(query).getResultList();
	}

	@Override
	public void eliminar(Long id) {
		// TODO Auto-generated method stub
		Usuario usuario= entityManager.find(Usuario.class, id);
		entityManager.remove(usuario);
		
	}

	@Override
	public void registrar(Usuario usuario) {
		// TODO Auto-generated method stub
		entityManager.merge(usuario);
	}

	@Override
	public boolean verificarCredenciales(Usuario usuario) {
		String query = "FROM Usuario WHERE email= :email";
		List<Usuario> lista=entityManager.createQuery(query).setParameter("email",usuario.getEmail()).getResultList();
		
		if(lista.isEmpty()) {
			return false;
		}
		
		String pass_hasheado=lista.get(0).getPassword();
		 
		Argon2 argon2= Argon2Factory.create(Argon2Factory.Argon2Types.ARGON2id);
		
		boolean passIgual=argon2.verify(pass_hasheado,usuario.getPassword());
		
		return passIgual;
	}

}
